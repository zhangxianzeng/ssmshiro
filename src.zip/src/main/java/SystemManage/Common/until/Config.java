package SystemManage.Common.until;

/**
 * 系统参数
 */

public interface Config {
    Integer RESOURCE_MENU = 0; // 菜单
    Integer RESOURCE_BUTTON = 1; // 按钮
}
