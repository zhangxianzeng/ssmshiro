package SystemManage.UserManage.controller;


import SystemManage.Common.until.TokenUtil;
import SystemManage.Common.until.UserLoginToken;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/n")
public class ShiyanContr extends BaseContrller1 {

    @RequestMapping("/k")

    public String getSSS(){

        return getUser().getLoginname();
    }

    @RequestMapping("/f")
    public String getSSS1(){

        return "zzzzzzz";
    }
}
