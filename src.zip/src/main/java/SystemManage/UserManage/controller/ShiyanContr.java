package SystemManage.UserManage.controller;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/n")
public class ShiyanContr extends BaseContrller1 {

    @RequestMapping("/k")

    public String getSSS(){

        return getUser().getLoginname();
    }

}
