package SystemManage.UserManage.controller;

import SystemManage.Common.controller.BaseController;
import SystemManage.Common.entity.Result;
import SystemManage.Common.shiro.ShiroUtils;
import SystemManage.UserManage.entity.User;
import SystemManage.UserManage.service.UserService;
import SystemManage.tokenutil.service.TokenService;
import com.alibaba.fastjson.JSONObject;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.DisabledAccountException;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * @description：登录退出
 */
@Controller
public class LoginController extends BaseController{

@Autowired
private  TokenService tokenService;
@Autowired
    UserService userService;
    /**
     * 登录
     *
     * @param username 用户名
     * @param password 密码
     * @param txtCode
     * @param session
     * @return
     */
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    @ResponseBody
    public Result loginPost(String username, String password, String txtCode, HttpSession session, HttpServletResponse response) {
        Result result = new Result();
        JSONObject jsonObject = new JSONObject();
        // 比对验证码是否正确
//        if ( !(txtCode.equals(session.getAttribute("code") ) ) ) {
//            result.setMsg("验证码错误");
//            return result;
//        }
        Subject user = SecurityUtils.getSubject();

        UsernamePasswordToken token =
                new UsernamePasswordToken(username, password);
//        token.setRememberMe(true);
        try {
            user.login(token);

            User user1=userService.findUserByLoginName(username);
            String token1 = tokenService.addtoken(user1);
            jsonObject.put("token",token1);
            Cookie cookie = new Cookie("token", token1);
            cookie.setPath("/");
            response.addCookie(cookie);
        } catch (UnknownAccountException e) {
            result.setMsg("账号不存在");
            return result;
        } catch (DisabledAccountException e) {
            result.setMsg("账号未启用");
            return result;
        } catch (IncorrectCredentialsException e) {
            result.setMsg("密码错误");
            return result;
        } catch (RuntimeException e) {
            result.setMsg("未知错误,请刷新界面重新登录！重复登录没用请加群联系作者带上报错截图"+e.getMessage());
//            result.setMsg(e.getMessage());
            return result;
        }
        result.setSuccess(true);
        session.setAttribute("Id" , getUserId());
        result.setObj(jsonObject);
        return result;
    }

    /**
     * 退出
     *
     * @return
     */
    @RequestMapping("/logout")
//    @ResponseBody
    public String logout() {
        ShiroUtils.logout();
        return "redirect:/" ;
    }
}
